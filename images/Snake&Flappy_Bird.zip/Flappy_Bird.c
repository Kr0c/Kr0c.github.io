#include<time.h>
#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<windows.h>
#define M 23
#define N 35

int game[M-1][N-1];
int score;
int h;
int flag3;

void Init(){
	int i,j;
	for(i = 0; i <= M-1 ; i ++)
		for(j = 0; j <= N-1 ; j ++)
			game[i][j] = 0;
	for(i = 0; i <= M-1 ; i ++){
		for(j = 0; j <= N-1 ; j ++){
			game[0][j] = game[M-1][j] = 1;
			game[i][0] = game[i][N-1] = 1;
		}
	}
	game[h][15] = 3;
}

void Bird_Move(int action, int *f1, int *f2){
	if(game[h][16] == 1 || game[h+1][15] == 1 || game[h-1][15] == 1){
		*f1 = 0;
		*f2 = 0;
	}
    else if(action){
		h -= 2;
		game[h][15] = 3;
		game[h+2][15] = 0;
	}
	else{
		h ++;
		game[h][15] = 3;
		game[h-1][15] = 0;
	}
}

void Create_Pipe(int *r){
	int i;
	switch(flag3%10){
	case 1:
		srand(time(NULL));
	    *r = rand() % 8 + 4;
	    game[*r][N-3] = 1;
		game[*r+7][N-3] = 1; break;
	case 2:
	case 3:
	case 4:
		for( i = *r ; i >= 1 ; i -- )
			game[i][N-3] = 1;
		for( i = *r+7 ; i <= M-2 ; i ++ )
			game[i][N-3] = 1; break;
	case 5:
		game[*r][N-3] = 1;
		game[*r+7][N-3] = 1; break;
	default:
		break;
	}
	if(flag3 == 21 || (flag3 > 21 && (flag3 - 21)%10 == 0)){
		score ++;
		printf("\a");
	}
}

void Pipe_Move(){
	int i,j,temp;
	temp = game[h][15];
	for(i = 0; i <= M-1 ; i ++){
		for(j = 2; j <= N-3 ; j ++){
			game[i][j] = game[i][j+1];
		}
	}
	game[h][15] = temp;
	for(i = 1; i <= 14; i ++){
		if(game[h][i] != 1)
			game[h][i] = 0;
	}
}

void Draw(int flag1){
    int i,j;
	for(i = 0; i <= M-1 ; i ++){
		for(j = 0; j <= N-1 ; j ++){
			 if(game[i][j] == 3)
				printf("��");
			else if(game[i][j] == 1)
				printf("��");
			else
				printf("  ");
			if(j == N-1){
				switch(i){
				case  4 : printf("  Flappy\n");       break ;
				case  5 : printf("   Bird\n");        break ;
			    case  6 : printf(" @iH8ra1n\n");      break ;
			    case 10 : printf("  �ܵ÷�\n");       break ;
			    case 12 : printf("    %d\n",score);   break ;
				case 17 : printf("    ��\n");         break ;
			    case 18 : printf("    ��\n");         break ;
				case 19 : printf("    ��\n");         break ;
			    case 20 : printf("    ��\n");         break ;
			    case 21 : printf("    ��\n");         break ;
				case 14 : if(flag1 == 0){
					        system("color 47");
					        printf("GAME OVER\n");    break ;
						  }
			    default : printf("\n");
				}
			}
		}
	}
}

void main(){
	do{
		int t = 0;
		int ran = 0;
		int flag1 = 1;
		int flag2 = 1;
		score = 0;
		h = 11;
		flag3 = 0;
		system("color 3F");
		system("cls");
	    Init();
	    Draw(flag1);
	    while(flag2 == 1){
			char action = getch();
			while(!kbhit()){
				system("cls");
				flag3 ++;
				Create_Pipe(&ran);
		        Pipe_Move();
				Bird_Move(action,&flag1,&flag2);
		        Draw(flag1);
		        Sleep(200);
		        action = 0;
				if(flag2 == 0)
					break;
			}
		}
		system("pause");
	}while(!kbhit());
}
